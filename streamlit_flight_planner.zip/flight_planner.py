print('Flight planner app placeholder')
